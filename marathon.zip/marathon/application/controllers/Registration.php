<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Registration extends CI_Controller {

	public function  __construct(){ 
		parent:: __construct();
		$this->load->model(array('common_model'));
	} 

	/***********************************************************************
	** Function name: index 
	** Developed By: Tejaswi
	** Purpose: This function used for Registration
	** Date: 21 MAY 2021
	************************************************************************/

	public function index()
	{
		$data['error']	=	'';

		if($this->input->post('saveChanges')):
			$this->form_validation->set_rules('first_name','First Name','trim|required');
       		$this->form_validation->set_rules('last_name','Last Name','trim');
       		$this->form_validation->set_rules('email','Email','trim|required|valid_email');
       		$this->form_validation->set_rules('mobile_number','Mobile','trim|required|min_length[10]|max_length[12]');
       		$this->form_validation->set_rules('age','Age','trim|required|max_length[3]');
       		$this->form_validation->set_rules('state','State','trim|required');
       		$this->form_validation->set_rules('city','City','trim|required');
       		$this->form_validation->set_rules('pincode','Pincode','trim|required');

       		if($this->form_validation->run()):
       			$postField['atendee_first_name']  			=	stripslashes($this->input->post('first_name'));
       			$postField['atendee_last_name']  			=	stripslashes($this->input->post('last_name'));
       			$postField['atendee_email']  				=	stripslashes($this->input->post('email'));
       			$postField['atendee_mobile_number']  		=	stripslashes($this->input->post('mobile_number'));
       			$postField['atendee_age']  					=	stripslashes($this->input->post('age'));
       			$postField['state']  						=	stripslashes($this->input->post('state'));
       			$postField['city']  						=	stripslashes($this->input->post('city'));
       			$postField['pincode']  						=	stripslashes($this->input->post('pincode'));
       			$postField['order_id']  					=	rand(5,99999999);

       			$this->common_model->addData('event_registrations',$postField);
       			$this->session->set_userdata($postField);
       			redirect(base_url().'thank-you');
       		endif;
		endif;

		$this->layouts->set_title('New Gurugram HM, 28 Mar 2021, Karma Lakelands Event');
		$this->layouts->set_keyword('');
		$this->layouts->set_description('');

		$this->layouts->front_view('registration',array(),$data);
	}

	/***********************************************************************
	** Function name: thankYou 
	** Developed By: Tejaswi
	** Purpose: This function used for Order Success
	** Date: 21 MAY 2021
	************************************************************************/

	public function thankYou()
	{
		$data['error']	=	'';

		$this->layouts->set_title('New Gurugram HM, 28 Mar 2021, Karma Lakelands Event');
		$this->layouts->set_keyword('');
		$this->layouts->set_description('');

		$this->layouts->front_view('thankyou',array(),$data);
	}
}
