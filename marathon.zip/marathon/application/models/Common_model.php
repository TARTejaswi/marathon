<?php
if(!defined('BASEPATH')) exit('No direct script access allowed');
class Common_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct(); 
		$this->load->database(); 
	}
	
	/***********************************************************************
	** Function name : addData
	** Developed By : Tejaswi
	** Purpose  : This function used for add data
	** Date : 21 MAY 2021
	************************************************************************/
	public function addData($tableName='',$param=array())
	{
		$this->db->insert($tableName,$param);
		//echo $this->db->last_query();die;
		return $this->db->insert_id();

	}	// END OF FUNCTION
	
}	