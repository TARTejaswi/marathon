<!doctype html>
<html lang="eng">
	<head>
        <title>{title}</title>
        <!--META-->
        <meta http-equiv="Content-Type" content="width=device-width, initial-scale=1">
        <meta name="description" content="{description}">
        <meta name="keywords" content="{keyword}">
        <meta name="viewport" content="width=device-width">
        <meta name="theme-color" content="#fff" />
        <meta name="apple-mobile-web-app-status-bar-style" content="#fff">
        <!--end-->
		{head}
	</head>
	<body>
        <div class="mainwrapper" id="myDiv">
            {header}
            <div class="wrapper">
                {content}
            </div>
        </div>
	</body>
</html>