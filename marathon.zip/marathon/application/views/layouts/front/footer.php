<?php $generaldata = $this->front_model->get_general();//print_r($generaldata);die;?>
<?php $PRODUCTDATA =   $this->front_model->get_product_listing('multiple','','2');
        //print_r($generaldata);die;?>
<?php /*
Newsletter
		<section class="newsletter">
			<div class="container">
				<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                    <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
                        <div class="appbuttons">
                            <h4>User App</h4>
                            <p class="app-btn-row">
                                <a target="_blank" href="https://apps.apple.com/in/app/wems-road-side-assistance/id1488457318" class="app-btn change-icon">
                                    <img src="{ASSET_INCLUDE_URL}images/ios.png" class="img-responsive ios-black"> 
                                    <img src="{ASSET_INCLUDE_URL}images/ios-white.png" class="img-responsive ios-white"> App Store
                                </a>  
                                    <a target="_blank" href="https://play.google.com/store/apps/details?id=com.wemsuser.app" class="app-btn">
                                    <img src="{ASSET_INCLUDE_URL}images/google-play.png" class="img-responsive"> Play Store
                                </a>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
                        <div class="appbuttons">
                            <h4>Provider App</h4>
                            <p class="app-btn-row">
                                <a target="_blank" href="https://apps.apple.com/in/app/wems-provider-app/id1489145350" class="app-btn change-icon">
                                    <img src="{ASSET_INCLUDE_URL}images/ios.png" class="img-responsive ios-black"> 
                                    <img src="{ASSET_INCLUDE_URL}images/ios-white.png" class="img-responsive ios-white"> App Store
                                </a>  
                                    <a target="_blank" href="https://play.google.com/store/apps/details?id=com.WemsProvider.app" class="app-btn">
                                    <img src="{ASSET_INCLUDE_URL}images/google-play.png" class="img-responsive"> Play Store
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
			</div>
		</section>
*/ ?>
<!-- Footer Start -->

<footer>
			<section class="footer">
				<div class="container">
					<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
						<div class="col-lg-2 col-sm-2 col-md-2 col-xs-12">
							<h3>Quick Links</h3>
			
							<ul>
								<li><a href="<?php echo base_url();?>about-us">About Wems RSA</a></li>
								<li><a href="<?php echo base_url();?>overall-feedback">Feedback</a></li>
								<li><a href="<?php echo base_url();?>contact-us">Contact Us</a></li>
								<li><a href="<?php echo base_url();?>faqs">FAQs</a></li>
                                <?php if($this->session->userdata('USER_LOGIN') <> ""):?>
                                <!--<li><a href="<?php echo base_url();?>user/subscription">Subscription</a>-->
                                <?php elseif($this->session->userdata('MERCHANT_LOGIN') <> ""):?>
                                <li></li>
                                <?php else:?>
                                <!-- <li><a href="<?php echo base_url();?>subscription">Subscription</a> -->
                                
                                <?php endif;?>
								<li><a href="https://apps.apple.com/in/app/wems-provider-app/id1489145350">Provider's App Store</a>
                                <li><a href="https://play.google.com/store/apps/details?id=com.WemsProvider.app">Provider's Play Store</a>
                                
                                </li>
							</ul>
						</div>
						<div class="col-lg-2 col-sm-2 col-md-2 col-xs-12">
							<h3>Connect To</h3>
							<ul>
                                <li><a href="{BASE_URL}">Road side assistance</a></li>
                                <li><a href="{BASE_URL}buy-vehicle">Buy your car</a></li>
                                <li><a href="{BASE_URL}buy-sell/my-vehicles">Sell your car</a></li>
								<li><a href="{BASE_URL}autoparts">Auto Parts</a></li>
								<!-- <li><a href="#redirectservices">Lockout</a></li>
								<li><a href="#redirectservices">Mechanics</a></li>
								<li><a href="#redirectservices">Electrical/Battery</a></li>
								<li><a href="#redirectservices">Tow Truck</a></li>
								<li><a href="#redirectservices">Car Body Work</a></li> -->
							</ul>
						</div>
						<div class="col-lg-2 col-sm-2 col-md-2 col-xs-12">
							<h3>Connect With</h3>
							<ul>
                                <li><a href="#">Tires</a></li>
                                <li><a href="#">Lockout</a></li>
                                <li><a href="#">Mechanics</a></li>
								<li><a href="#">Electrical / Battery</a></li>
                                <li><a href="#">Tow Truck</a></li>
                                <li><a href="#">Car Body Work</a></li>
                                <li><a href="#">Car Wash</a></li>
							</ul>
						</div>
						<div class="col-lg-3 col-sm-3 col-md-3 col-xs-12">
							<h3>User Apps</h3>
							<a target="_blank" href="https://play.google.com/store/apps/details?id=com.wemsuser.app">
                                <img src="{BASE_URL}assets/front/images/google-play-ft.png" class="img-responsive" alt="Google Play"/>
                            </a>
                            &nbsp; &nbsp; 
                            <a target="_blank" href="https://apps.apple.com/in/app/wems-road-side-assistance/id1488457318">
                                <img src="{BASE_URL}assets/front/images/ios-ft.png" class="img-responsive" alt="IOS"/>
                            </a>
							<h3>Provider Apps</h3>
							<a target="_blank" href="https://play.google.com/store/apps/details?id=com.WemsProvider.app">
                                <img src="{BASE_URL}assets/front/images/google-play-ft.png" class="img-responsive" alt="Google Play"/>
                            </a>
                            &nbsp; &nbsp; 
                            <a target="_blank" href="https://apps.apple.com/in/app/wems-provider-app/id1489145350">
                                <img src="{BASE_URL}assets/front/images/ios-ft.png" class="img-responsive" alt="IOS"/>
                            </a>
						</div>
						<div class="col-lg-3 col-sm-3 col-md-3 col-xs-12">
							<h3>Newsletter Subscription</h3>
							<div class="newsletter" style="background:none; padding:0;">
							    <div class="sewrap">
            						<form method="post" action="" name="subscription" id="subscription">
            							<div class="search">
            								<input type="email" required name="email" id="email" class="searchTerm" placeholder="Enter your email">
            								<input type="submit" value="Send" name="Savechanges" id="Savechanges" class="searchButton">
            								
            							</div>
            						</form>
        						</div>
							</div>
							<div class="footer-social">
								<ul>
									<li><a target="_blank" class="facebook" href="<?php echo $generaldata['facebook_link']?>"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
									<li><a target="_blank" class="twitter" href="<?php echo $generaldata['twitter_link']?>"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									<li><a target="_blank" class="instagram" href="<?php echo $generaldata['instagram_link']?>"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</section>
			<div class="page-ending">
				<div class="container">
					<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
						<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
							<ul>
								<li><a href="<?php echo base_url();?>terms-conditions">Terms & Conditions </a> &nbsp; |</li>
								<li><a href="<?php echo base_url();?>privacy-policy">Privacy Policy   </a> &nbsp; |</li>
								<li><a href="<?php echo base_url();?>cookie-policy">Our Cookie Policy</a></li>
							</ul>
						</div>
						<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
							<p>Copyright &copy; <?php echo date('Y');?> <?php echo $generaldata['copyright']?>.</p>
						</div>
					</div>
				</div>
			</div>
		</footer>
<div class="alert-icon shadow-inner alertbox">
    <div class="alert alert-warning alert-success-style3 alert-st-bg2">
        <button type="button" class="close sucess-op" data-dismiss="alert" aria-label="Close">
            <span class="icon-sc-cl" aria-hidden="true">×</span>
        </button>
        <i class="fa fa-exclamation-triangle edu-warning-danger admin-check-pro admin-check-pro-clr2" aria-hidden="true"></i>
        <p>Loading...</p>
    </div>
    <div class="alert alert-danger alert-mg-b alert-success-style4 alert-st-bg3">
        <button type="button" class="close sucess-op" data-dismiss="alert" aria-label="Close">
            <span class="icon-sc-cl" aria-hidden="true">×</span>
        </button>
        <i class="fa fa-times edu-danger-error admin-check-pro admin-check-pro-clr3" aria-hidden="true"></i>
        <p>Loading...</p>
    </div>
    <div class="alert alert-success alert-success-style1 alert-st-bg">
        <button type="button" class="close sucess-op" data-dismiss="alert" aria-label="Close">
            <span class="icon-sc-cl" aria-hidden="true">×</span>
        </button>
        <i class="fa fa-check edu-checked-pro admin-check-pro admin-check-pro-clr" aria-hidden="true"></i>
        <p>Loading...</p>
    </div>
    <div class="alert alert-info alert-success-style2 alert-st-bg1">
        <button type="button" class="close sucess-op" data-dismiss="alert" aria-label="Close">
            <span class="icon-sc-cl" aria-hidden="true">×</span>
        </button>
        <i class="fa fa-info-circle edu-inform admin-check-pro admin-check-pro-clr1" aria-hidden="true"></i>
        <p>Loading...</p>
    </div>
</div>
<div id="freeaccess" class="modal fade subscirbe-modal" role="dialog">
    <div class="modal-dialog modal-md">
    
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
         <img src="{ASSET_URL}front/images/subscription.png" class="img-responsive center-block notification-icon" alt="WEMS"/>
      </div>
      <div class="modal-body">
         <h3>Hy User !</h3>
         <p>Its time to subscribe to get unlimited access .</p>
         <a class="" href="{BASE_URL}user/subscription">
        <div class="btn slider_btn yellow_hover">Buy Subscription
        </div></a>
      </div>
    </div>
    
    </div>
</div>	

<div id="freeaccess2" class="modal fade subscirbe-modal" role="dialog">
    <div class="modal-dialog modal-md">
    
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
         <img src="{ASSET_URL}front/images/subscription.png" class="img-responsive center-block notification-icon" alt="WEMS"/>
      </div>
      <div class="modal-body">
         <h3>Hi User! </h3>
         <p>To get access to more providers around your location, please download the WEMS-RSA App</p>
         <a class="" href="https://play.google.com/store/apps/details?id=com.wemsuser.app" target="_blank">
        <div class="btn slider_btn yellow_hover">Download APP
        </div></a>
      </div>
    </div>
    
    </div>
</div>
<?php if($PRODUCTDATA):?>
<div id="alerttime" class="card">
    <button type="button" class="close sucess-op" data-dismiss="alert" aria-label="Close">
        <span id="hidealert" class="icon-sc-cl closepro" aria-hidden="true">×</span>
    </button>
    <p style="background: #f8c301;padding: 15px;" class="loginprofile">Hy user , we have a new feature launched in our website.<br>Go have a look and start shopping.Happy Shopping!!</p>
      
    <?php foreach($PRODUCTDATA as $PD):?>
    <div class="col-md-12 col-lg-12 col-xs-12">
    <div class="row">
      <div class="card-body pt-0 pr-0 pl-0 pb-0">
        <div class="cart-list-product">
           <a class="float-right remove-cart" href="#"></a>
           <img class="img-fluid" src="<?php echo $PD['item_image']?>" alt="">
          <h5><a target="_blank" href="<?php echo base_url()?>products/"><?php echo $PD['item_name']?></a></h5>
          <h6><strong><span class="mdi mdi-approval"></span> Price</strong> <?php echo $PD['item_price'];?></h6>
          <h6><strong><span class="mdi mdi-approval"></span> Weight</strong> <?php echo $PD['item_weight'];?></h6>
          <p><?php echo substr($PD['short_description'], 0,20);?></p>
        </div>
       </div>
    </div>	
    </div>
<?php endforeach;?>
<br>
<a style="margin-top: 10px;width: 100%;text-align: center;" class="get-help" href="<?php echo base_url()?>products/" title="Products">Lets GO</a>
</div>
<?php endif;?>
<script type="text/javascript">
    <?php if($this->session->flashdata('alert_warning')): ?>
    	alertMessageModelPopup('<?php echo $this->session->flashdata('alert_warning'); ?>','Warning');
    <?php elseif($this->session->flashdata('alert_error')): ?>
    	alertMessageModelPopup('<?php echo $this->session->flashdata('alert_error'); ?>','Error');
    <?php elseif($this->session->flashdata('alert_success')): ?>
    	alertMessageModelPopup('<?php echo $this->session->flashdata('alert_success'); ?>','Success');
    <?php elseif($this->session->flashdata('alert_info')): ?>
    	alertMessageModelPopup('<?php echo $this->session->flashdata('alert_success'); ?>','Info');
    <?php endif; ?>
    ///////////			ALERT MESSAGE MODEL 		///////////////////
    function alertMessageModelPopup(message,type){	
    	$(".alert-icon.alertbox").addClass("active"); 
    	$(".alert-icon.alertbox").children('.alert').css("display","none");
    	if(type == 'Warning'){
    		$(".alert-icon.alertbox").children('.alert-warning').css("display","block");
    	$(".alert-icon.alertbox").children('.alert-warning').children('p').html(message);
    	} else if(type == 'Error') {
    		$(".alert-icon.alertbox").children('.alert-danger').css("display","block");
    	$(".alert-icon.alertbox").children('.alert-danger').children('p').html(message);
    	} else if(type == 'Success') {
    		$(".alert-icon.alertbox").children('.alert-success').css("display","block");
    	$(".alert-icon.alertbox").children('.alert-success').children('p').html(message);
    	} else if(type == 'Info') {
    		$(".alert-icon.alertbox").children('.alert-info').css("display","block");
    	$(".alert-icon.alertbox").children('.alert-info').children('p').html(message);
    	}
    	setTimeout(AlertMessageModelPopupTimedOut, 5000);
    }
    function AlertMessageModelPopupTimedOut() { 
    	$(".alert-icon.alertbox").removeClass("active");
    }
</script>
<!-- Disable Keys -->

<!-- <SCRIPT language=JavaScript>
var message = "function disabled";
function rtclickcheck(keyp){ if (navigator.appName == "Netscape" && keyp.which == 3){ alert(message); return false; }
if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) { alert(message); return false; } }
document.onmousedown = rtclickcheck;
</SCRIPT>

<script type="text/javascript">
	$(document).keydown(function (event) {
    if (event.keyCode == 123) { // Prevent F12
        return false;
    } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { // Prevent Ctrl+Shift+I        
        return false;
    }
});
</script>
<script>
document.onkeydown = function(e) {
        if (e.ctrlKey && 
            (e.keyCode === 85 || 
             e.keyCode === 117)) {
            return false;
        } else {
            return true;
        }
};
$(document).keypress("u",function(e) {
  if(e.ctrlKey)
  {
return false;
}
else
{
return true;
}
});
</script>
 -->

<script type="text/javascript">
    function autoRefreshPage()
    {
        window.location = window.location.href;
    }
    setInterval('autoRefreshPage()', 900000);
</script>
<?php /*if(($this->session->userdata('is_pay') == '0') || ($this->session->userdata('is_pay') == '3')):?>
<script type="text/javascript">
    setTimeout(function() {
    $('#freeaccess').modal();
}, 200000);
</script>
<?php endif;*/?>

<!-- End -->
<div id="messagealert" class="modal fade subscirbe-modal" role="dialog">
    <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
         <img src="{ASSET_URL}front/images/subscription.png" class="img-responsive center-block notification-icon" alt="WEMS"/>
      </div>
      <div class="modal-body">
         
      </div>
    </div>
    
    </div>
</div>
<!-- Message Modal -->
<div id="myViewDetailsModal" class="modal" role="dialog">
  <div class="modal-dialog modal-md"> 
    <div class="modal-content">
      <div class="modal-header">
          <button data-dismiss="modal" class="close" type="button">x</button>
          <h3>Pop up Header</h3>
       </div>
      <div class="modal-body">
        <p>Loading...</p>
      </div>
    </div>
  </div>
</div> 
<!-- Cart -->
<script>
    $(document).on('click','.add-to-mycart',function(){
        var curObj          =   $(this); 
        var productId       =   curObj.attr('data'); 
        var countId         =   curObj.attr('id');
        var userId          =   window.btoa(USERID);
        var cookieId        =   window.btoa(readCookie('currentCartCookie'));
        if(countId > 0){
            var quantity        =   curObj.parents().find('div.number .quantity_'+countId+'').val();
        }
        else{
            var quantity        =   curObj.parents().find('div.number #quantity').val();
        }
        var price           =   curObj.attr('data-id'); 
        $.ajax({
            type: 'post',
             url: BASEURL+'user/addtomycart',
            data: {cookieId:cookieId,userId:userId,productId:productId,quantity:quantity,price:price},
         success: function(response){ 
                if(response.success == 0) {
                    alertMessageModelPopup(response.message,'Error');
                } else if(response.success == 1) {
                    alertMessageModelPopup(response.message,'Success');
                    $('.header-cart-count').find('small').remove();
                    $('.header-cart-count').append(response.result);
                } else if(response.success == 2) {
                    alertMessageModelPopup(response.message,'Warning');
                    $('.header-cart-count').find('small').remove();
                    $('.header-cart-count').append(response.result);
                }
            }
        });
    });

    $(function(){
        getHeaderCartCount();
    });

    function getHeaderCartCount(){
        var userId          =   window.btoa(USERID);
        var cookieId        =   window.btoa(readCookie('currentCartCookie'));
        $.ajax({
            type: 'post',
             url: BASEURL+'user/getfrommycart',
            data: {cookieId:cookieId,userId:userId},
         success: function(response){  
                if(response.success == 0) {
                    $('.header-cart-count').find('small').remove();
                } else if(response.success == 1) { 
                    $('.header-cart-count').find('small').remove();
                    $('.header-cart-count').append(response.result);
                }
            }
        });
    }
</script>

<script>
    $(document).ready(function() {
        $('.minus').click(function () {
            var input = $(this).parent().find('input#quantity');
            var count = parseInt(input.val()) - 1;
            count = count < 1 ? 1 : count;
            input.val(count);
            input.change();
            return false;
        });
        $('.plus').click(function () {
            var input = $(this).parent().find('input#quantity');
            var value = parseInt(input.val());
            var limit = $(this).attr('id'); 
            if (value < limit) value = value + 1; else {value = limit; alert('Limit exceeded for this product');}
            //input.val(parseInt(input.val()) + 1);
            input.val(value);
            input.change();
            return false;
        });
    });
</script>
<!-- Cart -->
<!-- Order -->
<script type="text/javascript">
  ///////////     VIEW DETAILS MODEL    ///////////////////
$(document).on('click','.table .view-details-data',function(){ 
  var title = $(this).attr('title');
  $("#myViewDetailsModal").modal();
  $("#myViewDetailsModal .modal-header h3").html(title);
  var viewid  = $(this).attr('data-id');
  var modelwidth  = $(this).attr('data-width');
  if(modelwidth){
    $("#myViewDetailsModal .modal-dialog").css('width',modelwidth);
  }
    
  $.ajax({
    type: 'post',
     url: BASEURL+'users/get_view_data',
    data: {csrf_api_key:csrf_api_value,viewid:viewid},
   success: function(response){
      $("#myViewDetailsModal .modal-body").html(response);
    } 
  });
});

</script>
<!-- Order -->

<!-- <script type="text/javascript">
     $(document).ready(function(){
        //alert(readCookie('hideAlertCookie'));
        if(!readCookie('hideAlertCookie')){
        setTimeout(function(){ 
            $('#alerttime').show(); 
            $("#alerttime").animate();
        }, 10000);
    }
    });
</script> -->
<script type="text/javascript">
    $(document).ready(function(){
        $('#hidealert').on('click',function(){
            if(!readCookie('hideAlertCookie')){
                var randomNumber = getRandomInt(1000000000000000,9999999999999999); 
                createCookie('hideAlertCookie', randomNumber, 7);
            } 
        });
    });
</script>

<script>
    $(document).on('click','.add-to-wishlist',function(){  
        var curObj          =   $(this); 
        if(USERID != 0) {
            var productId   =   curObj.attr('data'); 
            var userId      =   window.btoa(USERID);
            $.ajax({
                type: 'post',
                 url: BASEURL+'user/addtowishlist',
                data: {userId:userId,productId:productId},
             success: function(response){ 
                    if(response.success == 0) {
                        alertMessageModelPopup(response.message,'Error');
                    } else if(response.success == 1) {
                        alertMessageModelPopup(response.message,'Success');
                        curObj.html('<i class="fa fa-heart" aria-hidden="true"></i>')
                    } else if(response.success == 2) {
                        alertMessageModelPopup(response.message,'Success');
                        curObj.removeClass('active');
                    }
                }
            });
        } else { 
            var productId   =   'ADDTOWISHLIST'+curObj.attr('data'); 
            var message     =   '<span>Please Login to save this product as your wishlist.&nbsp;&nbsp;<a href="<?php echo base_url()?>user-login/" class="btn btn-default">Login</a></span>';
            alertMessageModelPopup(message,'Warning');
        }
    });
</script>

		