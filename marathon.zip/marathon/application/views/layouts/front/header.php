<header class="fixedHeader">
   <div class="menu">
      <div class="container">
         <div class="col-md-4 col-sm-4 col-xs-8">
               <div class="logo"> <a href="<?php echo base_url();?>" title=""> <img src="https://www.townscript.com/v2/assets/images/ts-bms-logo.svg" class="img-responsive" alt="Marathon" /> </a> 
                  <span class="borderline"></span><span class="safecheckout">Safe Checkout</span>
               </div>
         </div>
      </div>
   </div>
</header>
<!--end-->