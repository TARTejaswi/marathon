<link rel="icon" href="https://s3.ap-south-1.amazonaws.com/townscript-common-resources/images/custom/townscript_favicon_32.png" type="image/x-icon"/>
<!--All Fonts  Here -->
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.11.1/css/all.css">
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="{ASSET_URL}css/bootstrap.min.css">
<!-- style CSS -->			
<link rel="stylesheet" href="{ASSET_URL}css/style.css">
<link rel="stylesheet" href="https://unpkg.com/aos@2.3.0/dist/aos.css"/> 


<script type="text/ecmascript">
var BASEURL 			=	'{BASE_URL}';
var FULLSITEURL 		=	'{FULL_SITE_URL}';
var ASSETURL 			=	'{ASSET_URL}';
var CURRENTCLASS 		=	'{CURRENT_CLASS}';
var CURRENTMETHOD 		=	'{CURRENT_METHOD}';
var csrf_api_key		=	'<?php echo $this->security->get_csrf_token_name(); ?>';
var csrf_api_value 		=	'<?php echo $this->security->get_csrf_hash(); ?>';

</script>
<!-- jquery ============================================ -->
<script src="{ASSET_URL}js/jquery.js"></script>
<!-- bootstrap JS ============================================ -->
<script src="{ASSET_URL}js/bootstrap.min.js"></script>
<script type="text/javascript" src="{ASSET_URL}js/bootstrap.js"></script>

