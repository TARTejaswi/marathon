<div class="thankyou">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="success">
					<img src="{ASSET_URL}img/tick.png">
					<h3>Registration for the event is done successfully.</h3>
					<div>
						<p> <span class="title">Order Id : </span> #<?php echo $this->session->userdata('order_id');?></p>
						<p> <span class="title">Name : </span> <?php echo $this->session->userdata('atendee_first_name').' '.$this->session->userdata('atendee_last_name');?></p>
						<p> <span class="title">Email : </span> <?php echo $this->session->userdata('atendee_email');?></p>
						<p> <span class="title">MObile Number : </span> <?php echo $this->session->userdata('atendee_mobile_number');?></p>
						<p> <span class="title">Age : </span> <?php echo $this->session->userdata('atendee_age');?></p>
						<p> <span class="title">Location : </span> #<?php echo $this->session->userdata('state').' | '.$this->session->userdata('city').' | '.$this->session->userdata('pincode');?></p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>	

