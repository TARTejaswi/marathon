<div class="eventDetails">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="col-md-8 col-sm-8 col-xs-8">
					<i class="fa fa-arrow-left arrow" aria-hidden="true"></i>
					<div class="eventTitle">
						<h6> New Gurugram HM</h6>
					</div>
					<div class="eventdate">
						<p>28 Mar 2021 | 5:30 AM IST Onwards | Karma Lakelands</p>
					</div>
					<div class="tickets">
						<p>No Tickets Available</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="eventRegistration">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-9 col-sm-9 col-xs-9">
				<form id="eventForm" name="eventForm" class="eventForm" method="post" action="">
		            <div class="row jumbotron">
		                <div class="col-sm-6 form-group">
		                    <label for="name-f">First Name <span class="required">*</span></label>
		                    <input type="text" name="first_name" class="form-control" id="first_name" placeholder="Enter your first name." value="<?php if(set_value('first_name')):echo set_value('first_name');endif;?>">
		                	<?php if(form_error('first_name')):?>
		                		<label class="error"><?php echo form_error('first_name');?></label>
		                	<?php endif;?>
		                </div>
		                <div class="col-sm-6 form-group">
		                    <label for="name-l">Last name</label>
		                    <input type="text" class="form-control" name="last_name" class="form-control" id="last_name" placeholder="Enter your last name." value="<?php if(set_value('last_name')):echo set_value('last_name');endif;?>">
		                	<?php if(form_error('last_name')):?>
		                		<label class="error"><?php echo form_error('last_name');?></label>
		                	<?php endif;?>
		                </div>
		                <div class="col-sm-6 form-group">
		                    <label for="email">Email <span class="required">*</span></label>
		                    <input type="text" class="form-control" name="email" class="form-control" id="email" placeholder="Enter your email." value="<?php if(set_value('email')):echo set_value('email');endif;?>">
		                	<?php if(form_error('email')):?>
		                		<label class="error"><?php echo form_error('email');?></label>
		                	<?php endif;?>
		                </div>
		                <div class="col-sm-6 form-group">
		                    <label for="mobile">Mobile Number <span class="required">*</span></label>
		                    <input type="text" class="form-control" name="mobile_number" class="form-control" id="mobile_number" placeholder="Enter your mobile number." value="<?php if(set_value('mobile_number')):echo set_value('mobile_number');endif;?>">
		                	<?php if(form_error('mobile_number')):?>
		                		<label class="error"><?php echo form_error('mobile_number');?></label>
		                	<?php endif;?>
		                </div>
		                <div class="col-sm-6 form-group">
		                    <label for="age">Age <span class="required">*</span></label>
		                    <input type="text" class="form-control" name="age" class="form-control" id="age" placeholder="Age" value="<?php if(set_value('age')):echo set_value('age');endif;?>">
		                	<?php if(form_error('age')):?>
		                		<label class="error"><?php echo form_error('age');?></label>
		                	<?php endif;?>
		                </div>
		                <div class="col-sm-6 form-group">
		                    <label for="State">State <span class="required">*</span></label>
		                    <input type="text" class="form-control" name="state" class="form-control" id="state" placeholder="Enter your state name." value="<?php if(set_value('state')):echo set_value('state');endif;?>">
		                	<?php if(form_error('state')):?>
		                		<label class="error"><?php echo form_error('state');?></label>
		                	<?php endif;?>
		                </div>
		                <div class="col-sm-6 form-group">
		                    <label for="city">City <span class="required">*</span></label>
		                    <input type="text" class="form-control" name="city" class="form-control" id="city" placeholder="Village/City Name." value="<?php if(set_value('city')):echo set_value('city');endif;?>">
		                	<?php if(form_error('city')):?>
		                		<label class="error"><?php echo form_error('city');?></label>
		                	<?php endif;?>
		                </div>
		                <div class="col-sm-6 form-group">
		                    <label for="zip">Postal-Code <span class="required">*</span></label>
		                    <input type="text" class="form-control" name="pincode" class="form-control" id="pincode" placeholder="Postal-Code." value="<?php if(set_value('pincode')):echo set_value('pincode');endif;?>">
		                	<?php if(form_error('pincode')):?>
		                		<label class="error"><?php echo form_error('pincode');?></label>
		                	<?php endif;?>
		                </div>
		                 <div class="col-sm-12 form-group mb-0">
		                   <input type="submit" name="saveChanges" class="btn btn-primary float-right" value="Submit & Register">
		                </div>
		                <div class="col-sm-12 form-group mb-0" id="indication">
		                   <p class="float-right">Note :- <span class="required">*</span> Indicates required fields.</p>
		                </div>
		            </div>
        		</form>
			</div>
			<div class="col-md-3 col-sm-3 col-xs-3">
				<div class="coupon">
					<i class="fa fa-percent percent" aria-hidden="true"></i> <h5> Got a discount code?</h5><i class="fa fa-angle-down angledown" aria-hidden="true"></i>
				</div>
				<div class="noitems">
					<img src="{ASSET_URL}img/noitems.png">
					<p>No Items Added</p>
				</div>
			</div>
		</div>
	</div>
</div>	

