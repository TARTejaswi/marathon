<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Layouts
{
	// hold CI intance 
	private $CI;

	private $layout_title = NULL;
	private $layout_description = NULL;
	private $layout_keyword = NULL;
	
	public function __construct()
	{
		$this->CI = & get_instance();
	}

	public function front_view($view_name, $layouts=array(), $params=array(),$viewtype='')
	{	
		$this->CI->load->library('parser');
		if(is_array($layouts) && count($layouts) >=1):
			foreach($layouts as $layout_key => $layout):
				$params[$layout_key] = $this->CI->parser->parse($layout, $params, true);
			endforeach;
		endif;
		
		$params['BASE_URL']				= 	base_url();
		$params['ASSET_URL']			= 	base_url().'assets/';
		
		$params['CURRENT_CLASS']		= 	$this->CI->router->fetch_class();
		$params['CURRENT_METHOD']		= 	$this->CI->router->fetch_method();
		
		$pagedata['title'] 				= 	$this->layout_title?$this->layout_title:'Marathon';
		$pagedata['description']		= 	$this->layout_description;
		$pagedata['keyword'] 			= 	$this->layout_keyword;
		
		
		if($viewtype == 'onlyview'):
			$pagedata['head'] 				= 	$this->CI->parser->parse("layouts/front/head",$params,true);
			$pagedata['header'] 			= 	'';
			$pagedata['content']			= 	$this->CI->parser->parse($view_name,$params,true);
			$this->CI->parser->parse("layouts/front", $pagedata);
		else:
			$pagedata['head'] 				= 	$this->CI->parser->parse("layouts/front/head",$params,true);
			$pagedata['header'] 			= 	$this->CI->parser->parse("layouts/front/header",$params,true);
			$pagedata['content']			= 	$this->CI->parser->parse($view_name,$params,true);
			$this->CI->parser->parse("layouts/front", $pagedata);
		endif;
	}
	
	/**
     * Set page title
     *
     * @param $title
     */
    public function set_title($title)
	{
		$this->layout_title = $title;
		return $this;
	}
	
	/**
     * Set page description
     *
     * @param $description
     */
    public function set_description($description)
	{
		$this->layout_description = $description;
		return $this;
	}
	
	/**
     * Set page keyword
     *
     * @param $keyword
     */
    public function set_keyword($keyword)
	{
		$this->layout_keyword = $keyword;
		return $this;
	}
}